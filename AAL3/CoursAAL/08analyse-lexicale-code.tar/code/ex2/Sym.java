public enum Sym {
    INT, IDENT, PARG, PARD, MULT, PLUS;
}


