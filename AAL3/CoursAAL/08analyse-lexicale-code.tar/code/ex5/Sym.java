public enum Sym {
    IDENT, END, BEGIN, CLASS;

    public String str(){
	switch (this) {
	case IDENT: return "IDENT";
	case END: return "END";
	case BEGIN: return "BEGIN";
	case CLASS: return "CLASS";
	default: return "impossible";
	}
    }
}
